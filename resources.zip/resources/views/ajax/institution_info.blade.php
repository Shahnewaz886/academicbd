<img width="200" src="{{ ($institution_info->image)?env('APP_URL_FILE').$institution_info->image:'http://placehold.it/200x200' }}" alt="Institution Logo">
<h3>{{$institution_info->name}}</h3>